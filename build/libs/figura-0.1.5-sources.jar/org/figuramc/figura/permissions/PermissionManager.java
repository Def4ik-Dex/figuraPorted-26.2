package org.figuramc.figura.permissions;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import org.figuramc.figura.FiguraMod;
import org.figuramc.figura.config.Configs;
import org.figuramc.figura.entries.FiguraPermissions;
import org.figuramc.figura.utils.IOUtils;

public class PermissionManager {
   public static final Map<Permissions.Category, PermissionPack.CategoryPermissionPack> CATEGORIES = new LinkedHashMap<>();
   private static final Map<UUID, PermissionPack.PlayerPermissionPack> PLAYERS = new HashMap<>();
   private static final Set<UUID> BACKEND_CHECKED = new HashSet<>();
   public static final Map<String, Collection<Permissions>> CUSTOM_PERMISSIONS = new HashMap<>();

   public static void init() {
      for (Permissions.Category category : Permissions.Category.values()) {
         PermissionPack.CategoryPermissionPack container = new PermissionPack.CategoryPermissionPack(category);
         CATEGORIES.put(category, container);
      }

      IOUtils.readCacheFile("permissions", PermissionManager::readNbt);
   }

   public static void reinit() {
      BACKEND_CHECKED.clear();
      CATEGORIES.clear();
      PLAYERS.clear();
      init();
   }

   public static void initEntryPoints(Set<FiguraPermissions> set) {
      for (FiguraPermissions figuraPermissions : set) {
         CUSTOM_PERMISSIONS.put(figuraPermissions.getTitle(), figuraPermissions.getPermissions());
      }
   }

   private static void readNbt(CompoundTag nbt) {
      ListTag groupList = nbt.getListOrEmpty("groups");
      ListTag playerList = nbt.getListOrEmpty("players");

      for (Tag nbtElement : groupList) {
         CompoundTag compound = (CompoundTag)nbtElement;
         String name = (String)compound.getString("name").get();

         try {
            Permissions.Category category = Permissions.Category.valueOf(name);
            PermissionPack pack = CATEGORIES.get(category);
            pack.loadNbt(compound);
         } catch (Exception ignored) {
            FiguraMod.LOGGER.warn("Failed to load permissions for \"{}\"", name);
         }
      }

      for (Tag value : playerList) {
         CompoundTag compound = (CompoundTag)value;
         String name = (String)compound.getString("name").get();

         try {
            UUID uuid = UUID.fromString(name);
            String parent = (String)compound.getString("category").get();
            Permissions.Category category = Permissions.Category.valueOf(parent);
            PermissionPack.CategoryPermissionPack parentPack = CATEGORIES.get(category);
            PermissionPack.PlayerPermissionPack pack = new PermissionPack.PlayerPermissionPack(parentPack, name);
            pack.loadNbt(compound);
            PLAYERS.put(uuid, pack);
         } catch (Exception ignored) {
            FiguraMod.LOGGER.warn("Failed to load permissions for \"{}\"", name);
         }
      }
   }

   public static void saveToDisk() {
      IOUtils.saveCacheFile("permissions", nbt -> {
         ListTag groupList = new ListTag();
         ListTag playerList = new ListTag();

         for (PermissionPack group : CATEGORIES.values()) {
            if (group.hasChanges()) {
               CompoundTag container = new CompoundTag();
               group.writeNbt(container);
               groupList.add(container);
            }
         }

         for (PermissionPack.PlayerPermissionPack pack : PLAYERS.values()) {
            Permissions.Category category = getDefaultCategory();
            if (category == null) {
               category = Permissions.Category.DEFAULT;
            }

            if (pack.hasChanges() || pack.getCategory() != category) {
               CompoundTag container = new CompoundTag();
               pack.writeNbt(container);
               playerList.add(container);
            }
         }

         nbt.put("groups", groupList);
         nbt.put("players", playerList);
         FiguraMod.debug("Saved Permissions");
      });
   }

   public static PermissionPack.PlayerPermissionPack get(UUID id) {
      if (PLAYERS.containsKey(id)) {
         return PLAYERS.get(id);
      }

      Permissions.Category category = getDefaultCategory();
      if (FiguraMod.isLocal(id)) {
         category = Permissions.Category.MAX;
      } else if (category == null) {
         category = Permissions.Category.DEFAULT;
      }

      PermissionPack.PlayerPermissionPack pack = new PermissionPack.PlayerPermissionPack(CATEGORIES.get(category), id.toString());
      PLAYERS.put(id, pack);
      FiguraMod.debug("Created Permissions for: " + id);
      return pack;
   }

   public static PermissionPack.PlayerPermissionPack getMobPermissions(UUID id) {
      PermissionPack.PlayerPermissionPack pack = new PermissionPack.PlayerPermissionPack(CATEGORIES.get(Permissions.Category.MAX), id.toString());
      pack.insert(Permissions.OFFSCREEN_RENDERING, 0, "figura");
      return pack;
   }

   public static boolean increaseCategory(PermissionPack container) {
      return changeCategory(container, container.getCategory().index + 1);
   }

   public static boolean decreaseCategory(PermissionPack container) {
      return changeCategory(container, container.getCategory().index - 1);
   }

   private static boolean changeCategory(PermissionPack container, int index) {
      Permissions.Category newCategory = Permissions.Category.indexOf(index);
      if (newCategory == null) {
         return false;
      }

      container.setCategory(CATEGORIES.get(newCategory));
      saveToDisk();
      return true;
   }

   public static void setDefaultFor(UUID id, Permissions.Category defaultCat) {
      if (!BACKEND_CHECKED.contains(id)) {
         boolean canAdd;
         if (!PLAYERS.containsKey(id)) {
            canAdd = true;
         } else {
            PermissionPack.PlayerPermissionPack pack = PLAYERS.get(id);
            Permissions.Category def = getDefaultCategory();
            if (def == null) {
               def = Permissions.Category.DEFAULT;
            }

            canAdd = !pack.hasChanges() && pack.getCategory() == def;
         }

         if (canAdd) {
            PermissionPack.PlayerPermissionPack pack = new PermissionPack.PlayerPermissionPack(CATEGORIES.get(defaultCat), id.toString());
            PLAYERS.put(id, pack);
            FiguraMod.debug("Set permissions of {} to {} based on backend userdata", id, defaultCat.name());
         }

         BACKEND_CHECKED.add(id);
      }
   }

   public static Permissions.Category getDefaultCategory() {
      return Permissions.Category.indexOf(Configs.DEFAULT_PERMISSION_LEVEL.value);
   }
}
