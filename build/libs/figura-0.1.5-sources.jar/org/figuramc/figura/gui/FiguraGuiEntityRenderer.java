package org.figuramc.figura.gui;

import net.minecraft.client.gui.render.pip.GuiEntityRenderer;
//import net.minecraft.client.renderer.MultiBufferSource.BufferSource;//MultiBufferSource
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;

public class FiguraGuiEntityRenderer extends GuiEntityRenderer {
   public FiguraGuiEntityRenderer(EntityRenderDispatcher entityRenderDispatcher) {
      super(entityRenderDispatcher);
   }

   protected String getTextureLabel() {
      return "figura-entity";
   }
}
