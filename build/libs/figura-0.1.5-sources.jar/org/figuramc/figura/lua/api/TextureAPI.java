package org.figuramc.figura.lua.api;

import com.mojang.blaze3d.buffers.GpuBuffer;
//import com.mojang.blaze3d.buffers.GpuBuffer.MappedView;//MappedView
import com.mojang.blaze3d.buffers.GpuBufferSlice.MappedView;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import org.figuramc.figura.avatar.Avatar;
import org.figuramc.figura.lua.LuaNotNil;
import org.figuramc.figura.lua.LuaWhitelist;
import org.figuramc.figura.lua.docs.LuaMethodDoc;
import org.figuramc.figura.lua.docs.LuaMethodOverload;
import org.figuramc.figura.lua.docs.LuaTypeDoc;
import org.figuramc.figura.mixin.render.MissingTextureAtlasSpriteAccessor;
import org.figuramc.figura.mixin.render.TextureAtlasAccessor;
import org.figuramc.figura.model.rendering.texture.FiguraTexture;
import org.figuramc.figura.utils.ColorUtils;
import org.figuramc.figura.utils.LuaUtils;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaTable;

@LuaWhitelist
@LuaTypeDoc(name = "TextureAPI", value = "textures")
public class TextureAPI {
   public static final int TEXTURE_LIMIT = 128;
   private final Avatar owner;

   public TextureAPI(Avatar owner) {
      this.owner = owner;
   }

   private void check() {
      if (this.owner.renderer == null) {
         throw new LuaError("Avatar have no active renderer!");
      }
   }

   public FiguraTexture register(String name, NativeImage image, boolean ignoreSize) {
      return this.owner.registerTexture(name, image, ignoreSize);
   }

   @LuaWhitelist
   @LuaMethodDoc(
      overloads = @LuaMethodOverload(argumentTypes = {String.class, Integer.class, Integer.class}, argumentNames = {"name", "width", "height"}),
      value = "textures.new_texture"
   )
   public FiguraTexture newTexture(@LuaNotNil String name, int width, int height) {
      NativeImage image;
      try {
         image = new NativeImage(width, height, true);
      } catch (Exception e) {
         throw new LuaError(e.getMessage());
      }

      FiguraTexture texture = this.register(name, image, false);
      texture.fill(0, 0, width, height, ColorUtils.Colors.AWESOME_BLUE.vec.augmented(1.0), null, null, null);
      return texture;
   }

   @LuaWhitelist
   @LuaMethodDoc(
      overloads = {
            @LuaMethodOverload(argumentTypes = {String.class, String.class}, argumentNames = {"name", "base64Text"}),
            @LuaMethodOverload(argumentTypes = {String.class, LuaTable.class}, argumentNames = {"name", "byteArray"})
      },
      value = "textures.read"
   )
   public FiguraTexture read(@LuaNotNil String name, @LuaNotNil Object object) {
      byte[] bytes;
      if (object instanceof LuaTable table) {
         bytes = new byte[table.length()];

         for (int i = 0; i < bytes.length; i++) {
            bytes[i] = (byte)table.get(i + 1).checkint();
         }
      } else {
         if (!(object instanceof String s)) {
            throw new LuaError("Invalid type for read \"" + object.getClass().getSimpleName() + "\"");
         }

         bytes = Base64.getDecoder().decode(s);
      }

      NativeImage image;
      try {
         ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
         image = NativeImage.read(null, bais);
         bais.close();
      } catch (Exception e) {
         throw new LuaError("Could not read image: " + e.getMessage());
      }

      return this.register(name, image, false);
   }

   @LuaWhitelist
   @LuaMethodDoc(
      overloads = @LuaMethodOverload(argumentTypes = {String.class, FiguraTexture.class}, argumentNames = {"name", "texture"}),
      value = "textures.copy"
   )
   public FiguraTexture copy(@LuaNotNil String name, @LuaNotNil FiguraTexture texture) {
      NativeImage image = texture.copy();
      return this.register(name, image, false);
   }

   @LuaWhitelist
   @LuaMethodDoc(overloads = @LuaMethodOverload(argumentTypes = String.class, argumentNames = "name"), value = "textures.get")
   public FiguraTexture get(@LuaNotNil String name) {
      this.check();
      return this.owner.renderer.customTextures.get(name);
   }

   @LuaWhitelist
   @LuaMethodDoc("textures.get_textures")
   public List<FiguraTexture> getTextures() {
      this.check();
      return new ArrayList<>(this.owner.renderer.textures.values());
   }

   @LuaWhitelist
   @LuaMethodDoc(
      overloads = @LuaMethodOverload(argumentTypes = {String.class, String.class}, argumentNames = {"name", "path"}),
      value = "textures.from_vanilla"
   )
   public FiguraTexture fromVanilla(@LuaNotNil String name, @LuaNotNil String path) {
      this.check();
      Identifier resourceLocation = LuaUtils.parsePath(path);

      try {
         AbstractTexture atlas = Minecraft.getInstance().getTextureManager().getTexture(resourceLocation);
         if (!(atlas instanceof TextureAtlas)) {
            throw new LuaError("Resource is not a texture atlas: " + resourceLocation);
         }

         GpuTexture atlasGpuTexture = atlas.getTexture();
         TextureAtlasAccessor atlasAccessor = (TextureAtlasAccessor)atlas;
         NativeImage nativeImage = new NativeImage(atlasAccessor.figura$getWidth(), atlasAccessor.figura$getHeight(), false);
         int width = atlasAccessor.figura$getWidth();
         int height = atlasAccessor.figura$getHeight();
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         GpuBuffer gpuBuffer = RenderSystem.getDevice().createBuffer(() -> "Atlas Read Buffer", 9, width * height * atlasGpuTexture.getFormat()./*pixelSize*/blockSize());
         encoder.copyTextureToBuffer(atlasGpuTexture, gpuBuffer, 0L, () -> {
            MappedView readView = gpuBuffer.map(true, false);

            try {
               for (int k = 0; k < height; k++) {
                  for (int l = 0; l < width; l++) {
                     int m = readView./*data*/data().getInt((l + k * width) * atlasGpuTexture.getFormat()./*pixelSize*/blockSize());//pixelSize ? blockSize()
                     nativeImage.setPixelABGR(l, height - k - 1, m | 0xFF000000);
                  }
               }
            } catch (Throwable t$) {
               if (readView != null) {
                  try {
                     readView.close();//close
                  } catch (Throwable x2) {
                     t$.addSuppressed(x2);
                  }
               }

               throw t$;
            }

            if (readView != null) {
               readView.close();//close
            }

            gpuBuffer.close();
         }, 0);
         return this.register(name, nativeImage, false);
      } catch (Exception var13) {
         try {
            Optional<Resource> resource = Minecraft.getInstance().getResourceManager().getResource(resourceLocation);
            NativeImage image = resource.isPresent() ? NativeImage.read(resource.get().open()) : MissingTextureAtlasSpriteAccessor.generateImage(16, 16);
            return this.register(name, image, false);
         } catch (Exception e) {
            throw new LuaError(e.getMessage());
         }
      }
   }

   @LuaWhitelist
   public FiguraTexture __index(@LuaNotNil String name) {
      this.check();
      return this.owner.renderer.getTexture(name);
   }

   @Override
   public String toString() {
      return "TextureAPI";
   }
}
