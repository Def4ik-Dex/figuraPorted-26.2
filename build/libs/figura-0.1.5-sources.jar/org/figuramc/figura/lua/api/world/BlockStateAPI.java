package org.figuramc.figura.lua.api.world;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.BlockStateModelSet;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.util.ProblemReporter;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.storage.TagValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.figuramc.figura.lua.LuaWhitelist;
import org.figuramc.figura.lua.NbtToLua;
import org.figuramc.figura.lua.ReadOnlyLuaTable;
import org.figuramc.figura.lua.docs.LuaFieldDoc;
import org.figuramc.figura.lua.docs.LuaMethodDoc;
import org.figuramc.figura.lua.docs.LuaMethodOverload;
import org.figuramc.figura.lua.docs.LuaTypeDoc;
import org.figuramc.figura.math.vector.FiguraVec3;
import org.figuramc.figura.mixin.BlockBehaviourAccessor;
import org.figuramc.figura.utils.ColorUtils;
import org.figuramc.figura.utils.LuaUtils;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;

@LuaWhitelist
@LuaTypeDoc(name = "BlockState", value = "blockstate")
public class BlockStateAPI {
   public final BlockState blockState;
   private BlockPos pos;
   @LuaWhitelist
   @LuaFieldDoc("blockstate.id")
   public final String id;
   @LuaWhitelist
   @LuaFieldDoc("blockstate.properties")
   public final LuaTable properties;

   public BlockStateAPI(BlockState blockstate, BlockPos pos) {
      this.blockState = blockstate;
      this.pos = pos;
      this.id = BuiltInRegistries.BLOCK.getKey(blockstate.getBlock()).toString();
      CompoundTag tag = NbtUtils.writeBlockState(blockstate);
      this.properties = new ReadOnlyLuaTable((LuaValue)(tag.contains("Properties") ? NbtToLua.convert(tag.get("Properties")) : new LuaTable()));
   }

   protected BlockPos getBlockPos() {
      return this.pos == null ? BlockPos.ZERO : this.pos;
   }

   protected static List<List<FiguraVec3>> voxelShapeToTable(VoxelShape shape) {
      List<List<FiguraVec3>> shapes = new ArrayList<>();

      for (AABB aabb : shape.toAabbs()) {
         shapes.add(List.of(FiguraVec3.of(aabb.minX, aabb.minY, aabb.minZ), FiguraVec3.of(aabb.maxX, aabb.maxY, aabb.maxZ)));
      }

      return shapes;
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_id")
   public String getID() {
      return this.id;
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_properties")
   public LuaTable getProperties() {
      return this.properties;
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_pos")
   public FiguraVec3 getPos() {
      return FiguraVec3.fromBlockPos(this.getBlockPos());
   }

   @LuaWhitelist
   @LuaMethodDoc(
      overloads = {
            @LuaMethodOverload(argumentTypes = FiguraVec3.class, argumentNames = "pos"),
            @LuaMethodOverload(argumentTypes = {Double.class, Double.class, Double.class}, argumentNames = {"x", "y", "z"})
      },
      aliases = "pos",
      value = "blockstate.set_pos"
   )
   public BlockStateAPI setPos(Object x, Double y, Double z) {
      FiguraVec3 newPos = LuaUtils.parseVec3("setPos", x, y, z);
      this.pos = newPos.asBlockPos();
      return this;
   }

   @LuaWhitelist
   public BlockStateAPI pos(Object x, Double y, Double z) {
      return this.setPos(x, y, z);
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.is_translucent")
   public boolean isTranslucent() {
      return this.blockState.propagatesSkylightDown();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_opacity")
   public int getOpacity() {
      return this.blockState.getLightDampening();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_map_color")
   public FiguraVec3 getMapColor() {
      return ColorUtils.intToRGB(this.blockState.getMapColor(WorldAPI.getCurrentWorld(), this.getBlockPos()).col);
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.is_solid_block")
   public boolean isSolidBlock() {
      return this.blockState.isRedstoneConductor(WorldAPI.getCurrentWorld(), this.getBlockPos());
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.is_full_cube")
   public boolean isFullCube() {
      return this.blockState.isCollisionShapeFullBlock(WorldAPI.getCurrentWorld(), this.getBlockPos());
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.has_emissive_lighting")
   public boolean hasEmissiveLighting() {
      return this.blockState.emissiveRendering();//(WorldAPI.getCurrentWorld(), this.getBlockPos()); Expected no arguments but found 2
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_hardness")
   public float getHardness() {
      return this.blockState.getDestroySpeed(WorldAPI.getCurrentWorld(), this.getBlockPos());
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_comparator_output")
   public int getComparatorOutput() {
      return this.blockState.getAnalogOutputSignal(WorldAPI.getCurrentWorld(), this.getBlockPos(), null);
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.has_block_entity")
   public boolean hasBlockEntity() {
      return this.blockState.hasBlockEntity();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.is_opaque")
   public boolean isOpaque() {
      return this.blockState.canOcclude();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.emits_redstone_power")
   public boolean emitsRedstonePower() {
      return this.blockState.isSignalSource();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_luminance")
   public int getLuminance() {
      return this.blockState.getLightEmission();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_friction")
   public float getFriction() {
      return this.blockState.getBlock().getFriction();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_velocity_multiplier")
   public float getVelocityMultiplier() {
      return this.blockState.getBlock().getSpeedFactor();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_jump_velocity_multiplier")
   public float getJumpVelocityMultiplier() {
      return this.blockState.getBlock().getJumpFactor();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_blast_resistance")
   public float getBlastResistance() {
      return this.blockState.getBlock().getExplosionResistance();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.as_item")
   public ItemStackAPI asItem() {
      return ItemStackAPI.verify(this.blockState.getBlock().asItem().getDefaultInstance());
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_tags")
   public List<String> getTags() {
      List<String> list = new ArrayList<>();
      Registry<Block> registry = WorldAPI.getCurrentWorld().registryAccess().lookupOrThrow(Registries.BLOCK);
      Optional<ResourceKey<Block>> key = registry.getResourceKey(this.blockState.getBlock());
      if (key.isEmpty()) {
         return list;
      }

      for (TagKey<Block> blockTagKey : registry.getOrThrow(key.get()).tags().toList()) {
         list.add(blockTagKey.location().toString());
      }

      return list;
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.has_collision")
   public boolean hasCollision() {
      return ((BlockBehaviourAccessor)this.blockState.getBlock()).hasCollision();
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_collision_shape")
   public List<List<FiguraVec3>> getCollisionShape() {
      return voxelShapeToTable(this.blockState.getCollisionShape(WorldAPI.getCurrentWorld(), this.getBlockPos()));
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_outline_shape")
   public List<List<FiguraVec3>> getOutlineShape() {
      return voxelShapeToTable(this.blockState.getShape(WorldAPI.getCurrentWorld(), this.getBlockPos()));
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_sounds")
   public Map<String, Object> getSounds() {
      Map<String, Object> sounds = new HashMap<>();
      SoundType snd = this.blockState.getSoundType();
      sounds.put("pitch", snd.getPitch());
      sounds.put("volume", snd.getVolume());
      sounds.put("break", snd.getBreakSound().location().toString());
      sounds.put("fall", snd.getFallSound().location().toString());
      sounds.put("hit", snd.getHitSound().location().toString());
      sounds.put("place", snd.getPlaceSound().location().toString());
      sounds.put("step", snd.getStepSound().location().toString());
      return sounds;
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_fluid_tags")
   public List<String> getFluidTags() {
      List<String> list = new ArrayList<>();

      for (TagKey<Fluid> fluidTagKey : this.blockState.getFluidState().typeHolder().tags().toList()) {
         list.add(fluidTagKey.location().toString());
      }

      return list;
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_entity_data")
   public LuaTable getEntityData() {
      BlockEntity entity = WorldAPI.getCurrentWorld().getBlockEntity(this.getBlockPos());
      if (entity != null) {
         ItemStack stack = new ItemStack(entity.getBlockState().getBlock().asItem());
         TagValueOutput output = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, WorldAPI.getCurrentWorld().registryAccess());
         entity.saveCustomOnly(output);
         entity.removeComponentsFromTag(output);
         BlockItem.setBlockEntityData(stack, entity.getType(), output);
         stack.applyComponents(entity.collectComponents());
         LuaTable componentTable = (LuaTable)NbtToLua.convert(NbtToLua.convertToNbt(stack.getComponents()));
         LuaTable entityTable = (LuaTable)NbtToLua.convert(entity.saveWithoutMetadata(WorldAPI.getCurrentWorld().registryAccess()));
         LuaUtils.addLegacyNbtNames(componentTable, entityTable);
         return entityTable;
      } else {
         return null;
      }
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.to_state_string")
   public String toStateString() {
      BlockEntity entity = WorldAPI.getCurrentWorld().getBlockEntity(this.getBlockPos());
      CompoundTag tag = entity != null ? entity.saveWithoutMetadata(WorldAPI.getCurrentWorld().registryAccess()) : new CompoundTag();
      return BlockStateParser.serialize(this.blockState) + tag;
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.get_textures")
   public HashMap<String, Set<String>> getTextures() {
      HashMap<String, Set<String>> map = new HashMap<>();
      RenderShape renderShape = this.blockState.getRenderShape();
      if (renderShape == RenderShape.MODEL) {
         BlockStateModelSet blockRenderer = Minecraft.getInstance().getModelManager().getBlockStateModelSet();
         BlockStateModel bakedModel = blockRenderer.get(this.blockState);
         RandomSource randomSource = RandomSource.create();
         long seed = 42L;

         for (Direction direction : Direction.values()) {
            map.put(direction.name(), getTexturesForFace(this.blockState, direction, randomSource, bakedModel, seed));
         }

         map.put("NONE", getTexturesForFace(this.blockState, null, randomSource, bakedModel, seed));
         TextureAtlasSprite particle = blockRenderer.getParticleMaterial(this.blockState).sprite();
         map.put("PARTICLE", Set.of(getTextureName(particle)));
      }

      return map;
   }

   @LuaWhitelist
   @LuaMethodDoc("blockstate.is_air")
   public boolean isAir() {
      return this.blockState.isAir();
   }

   private static Set<String> getTexturesForFace(BlockState blockState, Direction direction, RandomSource randomSource, BlockStateModel bakedModel, long seed) {
      randomSource.setSeed(seed);
      List<BlockStateModelPart> blockModelParts = new ArrayList<>();
      bakedModel.collectParts(randomSource, blockModelParts);
      Set<String> textures = new HashSet<>();

      for (BlockStateModelPart part : blockModelParts) {
         for (BakedQuad quad : part.getQuads(direction)) {
            textures.add(getTextureName(quad.materialInfo().sprite()));
         }
      }

      return textures;
   }

   private static String getTextureName(TextureAtlasSprite sprite) {
      Identifier location = sprite.contents().name();
      return location.getNamespace() + ":textures/" + location.getPath();
   }

   @LuaWhitelist
   public boolean __eq(BlockStateAPI other) {
      return this.blockState.equals(other.blockState);
   }

   @LuaWhitelist
   public Object __index(String arg) {
      if (arg == null) {
         return null;
      }

      return switch (arg) {
         case "id" -> this.id;
         case "properties" -> this.properties;
         default -> null;
      };
   }

   @Override
   public String toString() {
      return this.id + " (BlockState)";
   }
}
