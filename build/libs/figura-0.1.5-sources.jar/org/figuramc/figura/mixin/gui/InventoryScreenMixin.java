package org.figuramc.figura.mixin.gui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.LivingEntity;
import org.figuramc.figura.avatar.AvatarManager;
import org.figuramc.figura.config.Configs;
import org.figuramc.figura.model.rendering.EntityRenderMode;
import org.figuramc.figura.utils.ui.UIHelper;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = InventoryScreen.class, priority = 999)
public class InventoryScreenMixin {
   @Inject(method = "extractEntityInInventoryFollowsMouse", at = @At("HEAD"), cancellable = true)
   private static void renderEntityInInventoryFollowsMouse(
      GuiGraphicsExtractor guiGraphics, int x, int y, int i, int j, int size, float yOffset, float mouseX, float mouseY, LivingEntity entity, CallbackInfo ci
   ) {
      if (Configs.FIGURA_INVENTORY.value && !AvatarManager.panic) {
         float g = (x + i) / 2.0F;
         float h = (y + j) / 2.0F;
         float pitch = g - mouseX;
         float yaw = h - mouseY;
         Vector3f modelOffset = new Vector3f(0.0F, entity.getBbHeight() / 2.0F + yOffset, 0.0F);
         if (Configs.INVENTORY_SCISSOR.value) {
            guiGraphics.enableScissor(x, y, i, j);
         }

         UIHelper.drawEntity(
            g,
            h,
            size,
            (float)Math.atan(yaw / 40.0F) * 20.0F,
            (float)(-Math.atan(pitch / 40.0F)) * 20.0F,
            entity,
            guiGraphics,
            modelOffset,
            EntityRenderMode.MINECRAFT_GUI,
            x,
            y,
            i,
            j
         );
         if (Configs.INVENTORY_SCISSOR.value) {
            guiGraphics.disableScissor();
         }

         ci.cancel();
      }
   }
}
