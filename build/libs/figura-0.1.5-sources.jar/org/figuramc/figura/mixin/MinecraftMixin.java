package org.figuramc.figura.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.Options;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.figuramc.figura.FiguraMod;
import org.figuramc.figura.avatar.Avatar;
import org.figuramc.figura.avatar.AvatarManager;
import org.figuramc.figura.backend2.NetworkStuff;
import org.figuramc.figura.config.Configs;
import org.figuramc.figura.gui.ActionWheel;
import org.figuramc.figura.gui.FiguraToast;
import org.figuramc.figura.gui.PopupMenu;
import org.figuramc.figura.gui.screens.WardrobeScreen;
import org.figuramc.figura.lua.FiguraLuaPrinter;
import org.figuramc.figura.utils.EntityUtils;
import org.figuramc.figura.utils.FiguraText;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
   @Shadow
   @Final
   public MouseHandler mouseHandler;
   @Shadow
   @Final
   public Options options;
   @Shadow
   public LocalPlayer player;
   @Unique
   private boolean scriptMouseUnlock = false;

   @Shadow
   public abstract void setScreenAndShow(@Nullable Screen var1);

   @Shadow
   public abstract Entity getCameraEntity();

   @Inject(at = @At("RETURN"), method = "handleKeybinds")
   private void handleKeybinds(CallbackInfo ci) {
      if (!AvatarManager.panic) {
         if (Configs.RELOAD_BUTTON.keyBind.consumeClick()) {
            AvatarManager.reloadAvatar(FiguraMod.getLocalPlayerUUID());
            FiguraToast.sendToast(FiguraText.of("toast.reload"));
         }

         if (Configs.WARDROBE_BUTTON.keyBind.consumeClick()) {
            this.setScreenAndShow(new WardrobeScreen(null));
         }

         Boolean wheel = null;
         if (Configs.ACTION_WHEEL_MODE.value % 2 == 1) {
            if (Configs.ACTION_WHEEL_BUTTON.keyBind.consumeClick()) {
               wheel = !ActionWheel.isEnabled();
            }
         } else if (Configs.ACTION_WHEEL_BUTTON.keyBind.isDown()) {
            wheel = true;
         } else if (ActionWheel.isEnabled()) {
            wheel = false;
         }

         if (wheel != null) {
            if (wheel) {
               ActionWheel.setEnabled(true);
               this.mouseHandler.releaseMouse();
            } else {
               if (Configs.ACTION_WHEEL_MODE.value >= 2) {
                  ActionWheel.execute(ActionWheel.getSelected(), true);
               }

               ActionWheel.setEnabled(false);
               this.mouseHandler.grabMouse();
            }
         }

         if (Configs.POPUP_BUTTON.keyBind.isDown()) {
            PopupMenu.setEnabled(true);
            if (!PopupMenu.hasEntity()) {
               Entity target = FiguraMod.extendedPickEntity;
               if (this.player != null && target instanceof Player && !target.isInvisibleTo(this.player)) {
                  PopupMenu.setEntity(target);
               } else if (!this.options.getCameraType().isFirstPerson()) {
                  PopupMenu.setEntity(this.getCameraEntity());
               }
            }
         } else if (PopupMenu.isEnabled()) {
            PopupMenu.run();
         }

         Avatar avatar = AvatarManager.getAvatarForPlayer(FiguraMod.getLocalPlayerUUID());
         if (avatar != null && avatar.luaRuntime != null && avatar.luaRuntime.host.unlockCursor) {
            this.mouseHandler.releaseMouse();
            this.scriptMouseUnlock = true;
         } else if (this.scriptMouseUnlock) {
            this.mouseHandler.grabMouse();
            this.scriptMouseUnlock = false;
         }
      }
   }

   @Inject(
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getInventory()Lnet/minecraft/world/entity/player/Inventory;"),
      method = "handleKeybinds",
      locals = LocalCapture.CAPTURE_FAILSOFT
   )
   private void handleHotbarSlots(CallbackInfo ci, int i) {
      if (PopupMenu.isEnabled()) {
         PopupMenu.hotbarKeyPressed(i);
      }

      if (ActionWheel.isEnabled()) {
         ActionWheel.hotbarKeyPressed(i);
      }
   }

   @Inject(at = @At("HEAD"), method = "setScreenAndShow")
   private void setScreen(Screen screen, CallbackInfo ci) {
      if (ActionWheel.isEnabled()) {
         ActionWheel.setEnabled(false);
      }

      if (PopupMenu.isEnabled()) {
         PopupMenu.run();
      }
   }

   @Inject(at = @At("RETURN"), method = "clearClientLevel")
   private void clearLevel(Screen screen, CallbackInfo ci) {
      AvatarManager.clearAllAvatars();
      FiguraLuaPrinter.clearPrintQueue();
      NetworkStuff.unsubscribeAll();
   }

   @Inject(at = @At("RETURN"), method = "setLevel")
   private void setLevel(ClientLevel world, CallbackInfo ci) {
      NetworkStuff.auth();
   }

   @Inject(at = @At("HEAD"), method = "runTick")
   private void preTick(boolean tick, CallbackInfo ci) {
      AvatarManager.executeAll("applyBBAnimations", Avatar::applyAnimations);
   }

   @Inject(at = @At("RETURN"), method = "runTick")
   private void afterTick(boolean tick, CallbackInfo ci) {
      AvatarManager.executeAll("clearBBAnimations", Avatar::clearAnimations);
   }

   @Inject(at = @At("RETURN"), method = "tick")
   private void startTick(CallbackInfo ci) {
      FiguraMod.pushProfiler("figura");
      FiguraMod.tick();
      FiguraMod.popProfiler();
   }

   @Inject(method = "pick(F)V", at = @At("RETURN"))
   private void pick(float tickDelta, CallbackInfo ci) {
      FiguraMod.pushProfiler("figura");
      FiguraMod.pushProfiler("extendedPick");
      FiguraMod.extendedPickEntity = EntityUtils.getViewedEntity(32.0F);
      FiguraMod.popProfiler(2);
   }
}
